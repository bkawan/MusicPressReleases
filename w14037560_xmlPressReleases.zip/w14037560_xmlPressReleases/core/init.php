<?php
session_start();

/**
 * global configuarion to store the session values
 */
$GLOBALS['config'] = array(
	'session'  => array(
		'session_subscriberID' => 'subscriberID',
		'session_email'        => 'email',
		'session_name'         => 'name',
		'token_name'           => 'token'
	)
);

?>









